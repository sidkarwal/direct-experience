var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// data/posts.json
var require_posts = __commonJS({
  "data/posts.json"(exports2, module2) {
    module2.exports = [
      {
        id: "1",
        url: "https://nadia.xyz/jhanas",
        headline: "I Hit Jhana 9 (Cessation) in 21.5 Hours Across Two Retreats \u2014 Here's What Each State Actually Felt Like",
        description: "Nadia Asparouhova documents her progression through all nine jhanic states across two 2024 retreats with unusual specificity \u2014 color associations, tactile metaphors, and temporal markers for each absorption. She's explicit that J9 cannot be described because consciousness switches off. Deliberately non-evangelical: she warns against pushing, notes personal variation, and makes no claims about what you should do.",
        source: "blog",
        domain: "nadia.xyz",
        tags: ["jhana", "precise-description", "nondual"],
        status: "approved",
        date_posted: "2026-06-19T08:00:00.000Z",
        seeded_by: "claude"
      },
      {
        id: "2",
        url: "https://www.psychologytoday.com/us/blog/ten-zen-questions/201410/the-first-jhana",
        headline: "My Head Started Shaking Uncontrollably, Then I Was Filled With Joy \u2014 Entering the First Jhana",
        description: "Susan Blackmore, a consciousness researcher, describes entering first jhana on a Leigh Brasington retreat with the candor of a skeptic: she initially assumed she'd made it up. She documents specific somatic markers \u2014 head shaking, chin twitching, buzzing in the ears, rushes of heat \u2014 before giving in to idiot-grin joy. The self-doubt and eventual verification through shared peer experience give this precision without inflation.",
        source: "blog",
        domain: "psychologytoday.com",
        tags: ["jhana", "precise-description", "spontaneous"],
        status: "approved",
        date_posted: "2026-06-19T08:10:00.000Z",
        seeded_by: "claude"
      },
      {
        id: "3",
        url: "https://www.cheetahhouse.org/rising-falling",
        headline: "Meditation Both Saved My Life and Almost Ended It \u2014 24 Days Into a 60-Day Vipassana Retreat in Myanmar",
        description: "An anonymous practitioner describes the onset of involuntary body movements, hallucinations, paranoia, and eventual suicidal ideation during Mahasi Sayadaw method practice at a Burmese forest monastery. Teachers attributed the symptoms to contact with Ultimate Reality; the practitioner eventually fled and spent months in dissociated aftermath. No tradition recruiting \u2014 the account is specifically critical of how these experiences are handled.",
        source: "blog",
        domain: "cheetahhouse.org",
        tags: ["dark-night", "precise-description", "kundalini"],
        status: "approved",
        date_posted: "2026-06-19T08:20:00.000Z",
        seeded_by: "claude"
      },
      {
        id: "4",
        url: "https://conscious.tv/text/05.htm",
        headline: "The Floor Started Wobbling, Then the Sense of 'Me' Disappeared \u2014 A Feldenkrais Session Triggered It",
        description: "Halina Pytlasinska describes a nondual recognition triggered not by meditation but a Feldenkrais session, when a teacher said 'there is no inside or outside' and something flipped. She's precise about what followed: the floor wobbling, solidity dissolving, the sense of 'me' fading, then hours of descending love. Notably rigorous: she explicitly refuses the myth of ongoing bliss, says neurotic traits persist, and argues no practice is necessary for what you already are.",
        source: "interview",
        domain: "conscious.tv",
        tags: ["nondual", "spontaneous", "precise-description", "ego-dissolution"],
        status: "approved",
        date_posted: "2026-06-19T08:30:00.000Z",
        seeded_by: "claude"
      },
      {
        id: "5",
        url: "https://www.nderf.org/Experiences/1sarah_w_nde.html",
        headline: "Burned and Left for Dead in the Woods at 15 \u2014 Then a Rocky Plain, a Luminous Guide, and Music Made of Love",
        description: "Sarah W's NDE account from 1993 stands out for phenomenological specificity that doesn't fit standard NDE templates: no bright white tunnel, instead an unfamiliar rocky plain, grey mist, and music she describes as 'love and hope made into sound.' Her account has remained unchanged across 30 years. She distinguishes clearly between drug-induced hallucinations that stopped at tunnel entry and what came after \u2014 a rare methodological note in this genre.",
        source: "nde-registry",
        domain: "nderf.org",
        tags: ["nde-type", "precise-description", "ego-dissolution"],
        status: "approved",
        date_posted: "2026-06-19T08:40:00.000Z",
        seeded_by: "claude"
      },
      {
        id: "6",
        url: "https://archive.org/stream/roberts.experience-of-no-self/roberts.experience-of-no-self_djvu.txt",
        headline: "I Looked Inward for My Usual Self and Found Nothing \u2014 Then the Empty Space Expanded Until It Exploded",
        description: "Bernadette Roberts' 1982 book remains one of the most clinically specific accounts of permanent no-self realization in Western literature. She describes gazing inward after a library visit and finding only empty space where the familiar center had been, then a 'flood of quiet joy' \u2014 followed days later by that empty space expanding and exploding into permanent boundlessness. A Catholic contemplative with no available map.",
        source: "book-text",
        domain: "archive.org",
        tags: ["nondual", "ego-dissolution", "dark-night", "cross-tradition"],
        status: "approved",
        date_posted: "2026-06-19T08:50:00.000Z",
        seeded_by: "claude"
      },
      {
        id: "7",
        url: "https://batgap.com/gary-weber-transcript/",
        headline: "I Came Out of a Yoga Pose and 25 Years of Self-Referential Thought Had Simply Stopped",
        description: "Gary Weber, a Penn State research scientist with 25 years of practice, describes an awakening he didn't anticipate: mid-vinyasa, coming out of a pose he'd done thousands of times, the narrative 'I, me, my' simply ceased. He continued managing R&D teams afterward. He's precise about what stopped (self-referential future/past thought) and what didn't (task-relevant cognition), making this one of the more functionally grounded accounts of an abrupt nondual shift.",
        source: "interview",
        domain: "batgap.com",
        tags: ["nondual", "spontaneous", "precise-description", "ego-dissolution"],
        status: "approved",
        date_posted: "2026-06-19T09:00:00.000Z",
        seeded_by: "claude"
      },
      {
        id: "8",
        url: "https://medium.com/know-thyself-heal-thyself/what-my-kundalini-awakening-taught-me-57e613397095",
        headline: "A Hot Coal Doused With Lighter Fluid at the Base of My Spine \u2014 Then Energy Pausing at Each Center for Months",
        description: "Patrick Paul Garlinger describes kundalini rising over years of unguided progression, with the energy moving independently, pausing at each chakra in turn, sometimes electric and painful, sometimes smooth and blissful. He documents specific somatic phenomena \u2014 kriyas, involuntary shaking, sweating \u2014 and is explicit that he neither sought nor caused the awakening. He actively discourages others from forcing it.",
        source: "blog",
        domain: "medium.com",
        tags: ["kundalini", "spontaneous", "precise-description"],
        status: "approved",
        date_posted: "2026-06-19T09:10:00.000Z",
        seeded_by: "claude"
      },
      {
        id: "9",
        url: "https://www.dharmaoverground.org/discussion/-/message_boards/message/13422662",
        headline: "Cessation Was a Letdown \u2014 I Expected Something, Got a Gap, Then Everything Was Different",
        description: "A Dharma Overground practitioner describes repeated cessations on a spectrum from 'extremely tiny and relieving' to more dramatic ones where sensations faded 'like mist' and whooshed back. The frank disappointment \u2014 expecting a more dramatic marker of path attainment \u2014 is what makes this account valuable: it strips the mythologized bang from a real phenomenological event and describes only what was observably different before and after.",
        source: "forum",
        domain: "dharmaoverground.org",
        tags: ["jhana", "nondual", "precise-description", "cross-tradition"],
        status: "approved",
        date_posted: "2026-06-19T09:20:00.000Z",
        seeded_by: "claude"
      },
      {
        id: "10",
        url: "https://www.cheetahhouse.org/sense-of-self-domain",
        headline: "'I Was About Eight to Ten Inches to the Right of My Body' \u2014 Meditators Describe Sense-of-Self Dissolution",
        description: "Cheetah House's phenomenological documentation of sense-of-self changes across long-term meditators includes direct quotes spanning out-of-body displacement, boundary dissolution, agency loss, and basic self loss. These are witness accounts extracted from Brown University's Varieties of Contemplative Experience study \u2014 research interviews, not testimonials. Among the most rigorously sourced collections of first-person dissolution accounts available online.",
        source: "research",
        domain: "cheetahhouse.org",
        tags: ["ego-dissolution", "nondual", "dark-night", "precise-description"],
        status: "approved",
        date_posted: "2026-06-19T09:30:00.000Z",
        seeded_by: "claude"
      }
    ];
  }
});

// netlify/functions/posts.js
var posts = require_posts();
exports.handler = async () => {
  const approved = posts.filter((p) => p.status === "approved").sort((a, b) => new Date(b.date_posted) - new Date(a.date_posted));
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Cache-Control": "public, max-age=300"
    },
    body: JSON.stringify(approved)
  };
};
